import os
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters

# Seu token do Bot do Telegram
TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = 7666168366

# Ativar logs
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

# Mensagem de boas-vindas
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        """🎵 *Bem-vindo ao BandLebMusicbot!* 🇧🇷

Aqui você pode baixar músicas em MP3 com jeitinho brasileiro!

*Comandos disponíveis:*

/yt – Baixar música por link do YouTube
/funk – Músicas de funk
/pagode – Músicas de pagode
/brega – Músicas de brega
/reggae – Músicas de reggae
/instrucoes – Como usar o bot
/doar – Apoie o bot via Pix

Se você for o dono: digite /adm para acessar o painel de administrador.
""", parse_mode="Markdown")

# Instruções
async def instrucoes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        """📌 *Como usar o bot:*

1. Use /yt e envie um link do YouTube (música)
2. Ou escolha uma categoria como /funk, /pagode etc.
3. Receba a música em MP3 direto no Telegram!

Mais comandos: /doar para apoiar o projeto ❤️
""", parse_mode="Markdown")

# Comando doar
async def doar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("💸 Para ajudar o bot a continuar no ar, envie qualquer valor via Pix para esta chave aleatória:

🔑 `000201010211...`

Obrigado pelo apoio! ❤️", parse_mode="Markdown")

# Comando ADM
async def adm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id == ADMIN_ID:
        await update.message.reply_text("🔐 Acesso de administrador ativado! Use /painel para ver o painel de controle.")
    else:
        await update.message.reply_text("❌ Você não tem permissão para acessar o painel.")

# Comando painel (somente admin)
async def painel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id == ADMIN_ID:
        await update.message.reply_text("📊 Painel administrativo:

- Total de usuários: (em breve)
- Enviar mensagens: (em breve)")
    else:
        await update.message.reply_text("❌ Comando restrito.")

# Comando yt simulado
async def yt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🔗 Envie o link do YouTube para baixar a música em MP3.")

# Categorias
async def categoria(update: Update, context: ContextTypes.DEFAULT_TYPE):
    comando = update.message.text.replace("/", "")
    await update.message.reply_text(f"🎶 Você escolheu a categoria: *{comando.capitalize()}*.
Digite o nome da música que deseja.", parse_mode="Markdown")

# Main
if __name__ == '__main__':
    app = ApplicationBuilder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("instrucoes", instrucoes))
    app.add_handler(CommandHandler("doar", doar))
    app.add_handler(CommandHandler("adm", adm))
    app.add_handler(CommandHandler("painel", painel))
    app.add_handler(CommandHandler("yt", yt))
    app.add_handler(CommandHandler(["funk", "pagode", "brega", "reggae"], categoria))

    print("Bot iniciado...")
    app.run_polling()