# BandLebMusicbot 🇧🇷

Bot brasileiro para baixar músicas MP3 diretamente do Telegram, por categorias e link do YouTube.

## Comandos

- `/start` – Boas-vindas
- `/yt` – Baixar MP3 do YouTube
- `/doar` – Mostrar chave Pix
- `/instrucoes` – Como usar o bot
- `/funk`, `/pagode`, `/brega`, `/reggae` – Categorias musicais
- `/adm` – Acessar modo administrador (somente ID autorizado)
- `/painel` – Painel de controle (em breve)

## Rodando localmente

1. Instale dependências:
```
pip install -r requirements.txt
```

2. Exporte seu token:
```
export BOT_TOKEN='sua_chave_do_bot_aqui'
```

3. Rode o bot:
```
python bot.py
```